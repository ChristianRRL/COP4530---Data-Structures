Sources:
ADTs Data Structures and Problem Solving with C++
Wikipedia: Depth First Search; Breadth First Search; Dijkstra's Algorithm