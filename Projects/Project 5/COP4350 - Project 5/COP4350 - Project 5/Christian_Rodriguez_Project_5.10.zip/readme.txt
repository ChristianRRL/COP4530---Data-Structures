References:

C++ How to Program
ADTs Data Structures and Problem Solving with C++
http://en.wikipedia.org/wiki/Binary_search_tree